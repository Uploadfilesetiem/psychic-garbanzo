<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

include 'koneksi.php';

$query_produk = "SELECT * FROM produk WHERE stok > 0";
$result_produk = mysqli_query($koneksi, $query_produk);

if (isset($_POST['bayar'])) {
    $id_produk   = $_POST['id_produk'];
    $jumlah_beli = $_POST['jumlah_beli'];
    
    $q_detail  = "SELECT harga, stok FROM produk WHERE id_produk = $id_produk";
    $res_detail = mysqli_query($koneksi, $q_detail);
    $prod      = mysqli_fetch_assoc($res_detail);
    
    if ($jumlah_beli > $prod['stok']) {
        echo "<script>alert('Stok tidak mencukupi!');</script>";
    } else {
        $total_harga = $prod['harga'] * $jumlah_beli;
        
        $query_trans = "INSERT INTO transaksi (id_produk, jumlah_beli, total_harga) VALUES ($id_produk, $jumlah_beli, $total_harga)";
        $query_stok  = "UPDATE produk SET stok = stok - $jumlah_beli WHERE id_produk = $id_produk";
        
        if (mysqli_query($koneksi, $query_trans) && mysqli_query($koneksi, $query_stok)) {
            echo "<script>alert('Transaksi Berhasil! Total: Rp " . number_format($total_harga, 0, ',', '.') . "'); window.location='riwayat.php';</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kasir Transaksi - Toko Sembako Gemini</title>
    <style>
        :root {
            --bg-sidebar: #1e293b;
            --bg-body: #f8fafc;
            --primary: #3b82f6;
            --warning: #f59e0b;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', sans-serif; }
        body { background-color: var(--bg-body); display: flex; height: 100vh; }
        .sidebar { width: 260px; background-color: var(--bg-sidebar); color: white; padding: 25px 20px; display: flex; flex-direction: column; justify-content: space-between; }
        .sidebar-brand { font-size: 18pt; font-weight: bold; border-bottom: 1px solid #334155; padding-bottom: 15px; margin-bottom: 25px; }
        .sidebar-menu { list-style: none; flex-grow: 1; }
        .sidebar-menu a { display: block; padding: 12px 15px; color: #cbd5e1; text-decoration: none; border-radius: 8px; font-weight: 500; }
        .sidebar-menu a:hover, .sidebar-menu a.active { background-color: #334155; color: white; }
        .main-content { flex: 1; padding: 40px; overflow-y: auto; }
        .form-card { background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); max-width: 650px; border: 1px solid #e2e8f0; }
        h2 { margin-bottom: 15px; color: #1e293b; border-bottom: 2px solid #e2e8f0; padding-bottom: 10px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 6px; font-weight: 600; color: #475569; }
        input, select { width: 100%; padding: 12px; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 11pt; }
        .total-box { background: #f0fdf4; border: 2px dashed #16a34a; padding: 20px; border-radius: 8px; font-size: 16pt; font-weight: bold; color: #166534; margin: 20px 0; text-align: center; }
        button { background: var(--warning); color: #1e293b; border: none; padding: 14px 20px; font-weight: bold; border-radius: 8px; cursor: pointer; width: 100%; font-size: 12pt; transition: 0.2s; }
        button:hover { background: #d97706; }
    </style>
    <script>
        function hitungOtomatis() {
            var selectProduk = document.getElementById('id_produk');
            var jumlahBeli   = document.getElementById('jumlah_beli').value;
            var harga = selectProduk.options[selectProduk.selectedIndex].getAttribute('data-harga');
            if (harga && jumlahBeli) {
                var total = harga * jumlahBeli;
                document.getElementById('total_tampilan').innerText = "Rp " + total.toLocaleString('id-ID');
            } else {
                document.getElementById('total_tampilan').innerText = "Rp 0";
            }
        }
    </script>
</head>
<body>
    <div class="sidebar">
        <div>
            <div class="sidebar-brand">Gemini Store 🏪</div>
            <ul class="sidebar-menu">
                <li><a href="index.php">📊 Dashboard Utama</a></li>
                <li><a href="tambah.php">➕ Tambah Produk</a></li>
                <li><a href="transaksi.php" class="active">🛒 Kasir Transaksi</a></li>
                <li><a href="riwayat.php">📜 Riwayat Penjualan</a></li>
            </ul>
        </div>
    </div>
    <div class="main-content">
        <div class="form-card">
            <h2>🛒 Nota Kasir Digital</h2>
            <form action="" method="POST">
                <div class="form-group">
                    <label>Pilih Komoditas Sembako</label>
                    <select name="id_produk" id="id_produk" onchange="hitungOtomatis()" required>
                        <option value="">-- Pilih Sembako Tersedia --</option>
                        <?php 
                        mysqli_data_seek($result_produk, 0);
                        while($p = mysqli_fetch_assoc($result_produk)) { 
                            echo "<option value='".$p['id_produk']."' data-harga='".$p['harga']."'>".$p['nama_produk']." (Rp ".number_format($p['harga'],0,',','.')." | Sisa Stok: ".$p['stok'].")</option>";
                        } 
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Jumlah Pembelian</label>
                    <input type="number" name="jumlah_beli" id="jumlah_beli" min="1" placeholder="Masukkan Qty..." oninput="hitungOtomatis()" required>
                </div>
                <div class="total-box">
                    Total Bayar: <span id="total_tampilan">Rp 0</span>
                </div>
                <button type="submit" name="bayar">⚡ PROSES & CETAK STRUK</button>
            </form>
        </div>
    </div>
</body>
</html>