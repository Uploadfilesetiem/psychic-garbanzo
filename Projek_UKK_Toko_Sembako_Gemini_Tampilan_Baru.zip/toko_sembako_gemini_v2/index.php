<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

include 'koneksi.php';

// Menghitung ringkasan data untuk ditaruh di box widget
$res_total_produk = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM produk");
$total_produk = mysqli_fetch_assoc($res_total_produk)['total'];

$res_total_stok = mysqli_query($koneksi, "SELECT SUM(stok) as total FROM produk");
$total_stok = mysqli_fetch_assoc($res_total_stok)['total'] ?? 0;

$res_total_transaksi = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM transaksi");
$total_transaksi = mysqli_fetch_assoc($res_total_transaksi)['total'];

$query = "SELECT * FROM produk";
$result = mysqli_query($koneksi, $query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Modern - Toko Sembako Gemini</title>
    <style>
        :root {
            --bg-sidebar: #1e293b;
            --bg-body: #f8fafc;
            --primary: #3b82f6;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --text-main: #0f172a;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', system-ui, sans-serif; }
        body { background-color: var(--bg-body); color: var(--text-main); display: flex; height: 100vh; overflow: hidden; }
        
        /* Layout Sidebar Kiri Baru */
        .sidebar { width: 260px; background-color: var(--bg-sidebar); color: white; padding: 25px 20px; display: flex; flex-direction: column; justify-content: space-between; }
        .sidebar-brand { font-size: 18pt; font-weight: bold; letter-spacing: 1px; color: #f8fafc; border-bottom: 1px solid #334155; padding-bottom: 15px; margin-bottom: 25px; display: flex; align-items: center; gap: 10px; }
        .sidebar-menu { list-style: none; flex-grow: 1; }
        .sidebar-menu li { margin-bottom: 8px; }
        .sidebar-menu a { display: block; padding: 12px 15px; color: #cbd5e1; text-decoration: none; border-radius: 8px; font-weight: 500; transition: all 0.2s; }
        .sidebar-menu a:hover, .sidebar-menu a.active { background-color: #334155; color: white; transform: translateX(5px); }
        .logout-box { border-top: 1px solid #334155; padding-top: 15px; }
        .btn-logout { display: block; text-align: center; background-color: var(--danger); color: white; padding: 10px; text-decoration: none; border-radius: 8px; font-weight: bold; transition: 0.2s; }
        .btn-logout:hover { background-color: #dc2626; }

        /* Konten Utama Kanan */
        .main-content { flex: 1; padding: 40px; overflow-y: auto; }
        .top-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
        .top-header h2 { font-size: 22pt; color: #1e293b; }
        .user-badge { background: white; padding: 8px 20px; border-radius: 30px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); font-weight: 600; border: 1px solid #e2e8f0; font-size: 10pt; }
        
        /* Grid Widget Statis Singkat */
        .grid-widgets { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-bottom: 35px; }
        .widget-card { background: white; padding: 20px; border-radius: 12px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); border-left: 5px solid var(--primary); display: flex; flex-direction: column; }
        .widget-card.success { border-left-color: var(--success); }
        .widget-card.warning { border-left-color: var(--warning); }
        .widget-title { font-size: 9pt; text-transform: uppercase; letter-spacing: 0.5px; color: #64748b; margin-bottom: 5px; font-weight: 600; }
        .widget-value { font-size: 20pt; font-weight: 700; color: #1e293b; }

        /* Desain Data Table Modern */
        .data-card { background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); border: 1px solid #e2e8f0; }
        .data-card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .data-card-header h3 { font-size: 14pt; color: #1e293b; font-weight: 700; }
        .btn-action-add { background-color: var(--primary); color: white; text-decoration: none; padding: 10px 18px; border-radius: 8px; font-weight: bold; font-size: 9.5pt; transition: 0.2s; }
        .btn-action-add:hover { background-color: #2563eb; }

        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 14px 18px; text-align: left; }
        th { background-color: #f1f5f9; color: #475569; font-weight: 600; font-size: 10pt; text-transform: uppercase; border-bottom: 2px solid #e2e8f0; }
        td { border-bottom: 1px solid #f1f5f9; color: #334155; font-size: 11pt; }
        tr:last-child td { border-bottom: none; }
        tr:hover td { background-color: #f8fafc; }
        
        .badge-stok { background-color: #d1fae5; color: #065f46; padding: 4px 10px; border-radius: 6px; font-weight: bold; font-size: 9.5pt; }
        .badge-stok.empty { background-color: #fee2e2; color: #991b1b; }
        
        /* Tombol Manipulasi Data */
        .btn-table { text-decoration: none; padding: 6px 12px; border-radius: 6px; font-size: 9pt; font-weight: bold; margin-right: 5px; display: inline-block; }
        .btn-edit { background-color: #fef3c7; color: #92400e; }
        .btn-edit:hover { background-color: #fde68a; }
        .btn-delete { background-color: #fee2e2; color: #991b1b; }
        .btn-delete:hover { background-color: #fecaca; }
    </style>
</head>
<body>

    <!-- SIDEBAR KIRI BARU -->
    <div class="sidebar">
        <div>
            <div class="sidebar-brand">
                <span>Gemini Store 🏪</span>
            </div>
            <ul class="sidebar-menu">
                <li><a href="index.php" class="active">📊 Dashboard Utama</a></li>
                <li><a href="tambah.php">➕ Tambah Produk</a></li>
                <li><a href="transaksi.php">🛒 Kasir Transaksi</a></li>
                <li><a href="riwayat.php">📜 Riwayat Penjualan</a></li>
            </ul>
        </div>
        <div class="logout-box">
            <a href="logout.php" class="btn-logout" onclick="return confirm('Keluar dari sistem?')">Keluar Aplikasi</a>
        </div>
    </div>

    <!-- KONTEN UTAMA KANAN BARU -->
    <div class="main-content">
        <div class="top-header">
            <h2>Ringkasan Manajemen Toko</h2>
            <div class="user-badge">
                👤 User: <span style="color: var(--primary);"><?= $_SESSION['user']; ?></span> (SMK Muh Bambanglipuro)
            </div>
        </div>

        <!-- ROW WIDGET INFO BARU -->
        <div class="grid-widgets">
            <div class="widget-card">
                <span class="widget-title">Jenis Komoditas</span>
                <span class="widget-value"><?= $total_produk; ?> Produk</span>
            </div>
            <div class="widget-card success">
                <span class="widget-title">Total Stok Tersedia</span>
                <span class="widget-value"><?= $total_stok; ?> Pcs</span>
            </div>
            <div class="widget-card warning">
                <span class="widget-title">Total Transaksi Selesai</span>
                <span class="widget-value"><?= $total_transaksi; ?> Terjual</span>
            </div>
        </div>

        <!-- TABEL DATA PRODUK DENGAN TAMPILAN FRESH -->
        <div class="data-card">
            <div class="data-card-header">
                <h3>Daftar Inventaris Sembako</h3>
                <a href="tambah.php" class="btn-action-add">+ Tambah Komoditas Baru</a>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Nama Sembako</th>
                        <th>Harga Satuan</th>
                        <th>Stok Saat Ini</th>
                        <th style="text-align: center;">Tindakan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><b>#PRD-<?= $row['id_produk']; ?></b></td>
                        <td style="font-weight: 600; color: #1e293b;"><?= $row['nama_produk']; ?></td>
                        <td>Rp <?= number_format($row['harga'], 0, ',', '.'); ?></td>
                        <td>
                            <span class="badge-stok <?= ($row['stok'] == 0) ? 'empty' : ''; ?>">
                                <?= $row['stok']; ?> pcs
                            </span>
                        </td>
                        <td style="text-align: center;">
                            <a href="edit.php?id=<?= $row['id_produk']; ?>" class="btn-table btn-edit">✏️ Ubah</a>
                            <a href="hapus.php?id=<?= $row['id_produk']; ?>" class="btn-table btn-delete" onclick="return confirm('Hapus produk ini?')">🗑️ Hapus</a>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>