<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

include 'koneksi.php';

$id = $_GET['id'];
$query = "SELECT * FROM produk WHERE id_produk = $id";
$result = mysqli_query($koneksi, $query);
$data = mysqli_fetch_assoc($result);

if (isset($_POST['update'])) {
    $nama  = $_POST['nama_produk'];
    $harga = $_POST['harga'];
    $stok  = $_POST['stok'];

    $query_update = "UPDATE produk SET nama_produk='$nama', harga='$harga', stok='$stok' WHERE id_produk=$id";
    if (mysqli_query($koneksi, $query_update)) {
        header("Location: index.php");
    } else {
        echo "<script>alert('Gagal memperbarui data');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Produk Sembako</title>
    <style>
        :root {
            --bg-sidebar: #1e293b;
            --bg-body: #f8fafc;
            --primary: #3b82f6;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', sans-serif; }
        body { background-color: var(--bg-body); display: flex; height: 100vh; }
        .sidebar { width: 260px; background-color: var(--bg-sidebar); color: white; padding: 25px 20px; display: flex; flex-direction: column; justify-content: space-between; }
        .sidebar-brand { font-size: 18pt; font-weight: bold; border-bottom: 1px solid #334155; padding-bottom: 15px; margin-bottom: 25px; }
        .sidebar-menu { list-style: none; flex-grow: 1; }
        .sidebar-menu a { display: block; padding: 12px 15px; color: #cbd5e1; text-decoration: none; border-radius: 8px; font-weight: 500; }
        .sidebar-menu a:hover { background-color: #334155; color: white; }
        .main-content { flex: 1; padding: 40px; overflow-y: auto; }
        .form-card { background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); max-width: 600px; border: 1px solid #e2e8f0; }
        h2 { margin-bottom: 20px; color: #1e293b; border-bottom: 2px solid #e2e8f0; padding-bottom: 10px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 6px; font-weight: 600; color: #475569; }
        input { width: 100%; padding: 12px; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 11pt; }
        input:focus { border-color: var(--primary); outline: none; }
        .btn-group-form { display: flex; gap: 10px; margin-top: 25px; }
        button { background: #f59e0b; color: white; border: none; padding: 12px 20px; font-weight: bold; border-radius: 8px; cursor: pointer; flex: 1; font-size: 11pt; }
        .btn-back { background: #64748b; color: white; text-decoration: none; padding: 12px 20px; font-weight: bold; border-radius: 8px; text-align: center; width: 100px; }
    </style>
</head>
<body>
    <div class="sidebar">
        <div>
            <div class="sidebar-brand">Gemini Store 🏪</div>
            <ul class="sidebar-menu">
                <li><a href="index.php">📊 Dashboard Utama</a></li>
                <li><a href="tambah.php">➕ Tambah Produk</a></li>
                <li><a href="transaksi.php">🛒 Kasir Transaksi</a></li>
                <li><a href="riwayat.php">📜 Riwayat Penjualan</a></li>
            </ul>
        </div>
    </div>
    <div class="main-content">
        <div class="form-card">
            <h2>✏️ Koreksi & Edit Komoditas</h2>
            <form action="" method="POST">
                <div class="form-group">
                    <label>Nama Sembako</label>
                    <input type="text" name="nama_produk" value="<?= $data['nama_produk']; ?>" required>
                </div>
                <div class="form-group">
                    <label>Harga Satuan (Rp)</label>
                    <input type="number" name="harga" value="<?= $data['harga']; ?>" required>
                </div>
                <div class="form-group">
                    <label>Jumlah Ketersediaan Stok</label>
                    <input type="number" name="stok" value="<?= $data['stok']; ?>" required>
                </div>
                <div class="btn-group-form">
                    <button type="submit" name="update">🔄 Perbarui Logistik</button>
                    <a href="index.php" class="btn-back">Batal</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>