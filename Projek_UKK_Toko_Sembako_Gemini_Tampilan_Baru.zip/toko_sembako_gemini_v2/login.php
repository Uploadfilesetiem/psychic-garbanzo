<?php
session_start();
if (isset($_SESSION['login'])) {
    header("Location: index.php");
    exit;
}

$error = false;
if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username === 'admin' && $password === 'admin123') {
        $_SESSION['login'] = true;
        $_SESSION['user'] = $username;
        header("Location: index.php");
        exit;
    } else {
        $error = true;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login Modern - Toko Sembako Gemini</title>
    <style>
        body {
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .login-card {
            background: #ffffff;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 380px;
            text-align: center;
        }
        h2 { color: #1e3c72; margin-bottom: 10px; font-size: 26px; font-weight: 700; }
        p { color: #666; margin-bottom: 30px; font-size: 14px; }
        .form-control { width: 100%; padding: 14px; margin: 10px 0; border: 1px solid #e0e0e0; border-radius: 8px; box-sizing: border-box; font-size: 14px; background: #f8faof; transition: all 0.3s; }
        .form-control:focus { border-color: #2a5298; background: #fff; outline: none; box-shadow: 0 0 0 3px rgba(42,82,152,0.1); }
        button { width: 100%; padding: 14px; background: linear-gradient(to right, #1e3c72, #2a5298); border: none; color: white; font-size: 16px; font-weight: bold; border-radius: 8px; cursor: pointer; margin-top: 15px; box-shadow: 0 4px 12px rgba(42,82,152,0.3); transition: 0.3s; }
        button:hover { transform: translateY(-2px); box-shadow: 0 6px 15px rgba(42,82,152,0.4); }
        .error { color: #e63946; font-size: 14px; margin-bottom: 15px; font-weight: 600; background: #ffe3e5; padding: 10px; border-radius: 6px; }
    </style>
</head>
<body>
<div class="login-card">
    <h2>Toko Gemini 🏪</h2>
    <p>Ujian Praktik Kenaikan Kelas (UKK) RPL X</p>
    <?php if ($error) : ?>
        <div class="error">❌ Username / Password Salah!</div>
    <?php endif; ?>
    <form action="" method="POST">
        <input type="text" name="username" class="form-control" placeholder="Username (admin)" required autocomplete="off">
        <input type="password" name="password" class="form-control" placeholder="Password (admin123)" required>
        <button type="submit" name="submit">MASUK KE SISTEM</button>
    </form>
</div>
</body>
</html>