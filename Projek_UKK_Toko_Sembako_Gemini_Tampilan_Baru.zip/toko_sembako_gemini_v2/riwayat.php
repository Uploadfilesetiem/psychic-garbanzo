<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
}

include 'koneksi.php';
$query = "SELECT t.*, p.nama_produk, p.harga FROM transaksi t JOIN produk p ON t.id_produk = p.id_produk ORDER BY t.tanggal_transaksi DESC";
$result = mysqli_query($koneksi, $query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Riwayat Penjualan Gemini</title>
    <style>
        :root {
            --bg-sidebar: #1e293b;
            --bg-body: #f8fafc;
            --primary: #3b82f6;
            --success: #10b981;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', sans-serif; }
        body { background-color: var(--bg-body); display: flex; height: 100vh; }
        .sidebar { width: 260px; background-color: var(--bg-sidebar); color: white; padding: 25px 20px; display: flex; flex-direction: column; justify-content: space-between; }
        .sidebar-brand { font-size: 18pt; font-weight: bold; border-bottom: 1px solid #334155; padding-bottom: 15px; margin-bottom: 25px; }
        .sidebar-menu { list-style: none; flex-grow: 1; }
        .sidebar-menu a { display: block; padding: 12px 15px; color: #cbd5e1; text-decoration: none; border-radius: 8px; font-weight: 500; }
        .sidebar-menu a:hover, .sidebar-menu a.active { background-color: #334155; color: white; }
        .main-content { flex: 1; padding: 40px; overflow-y: auto; }
        .data-card { background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); border: 1px solid #e2e8f0; }
        h2 { margin-bottom: 10px; color: #1e293b; }
        p { color: #64748b; margin-bottom: 25px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 14px 18px; text-align: left; }
        th { background-color: #f1f5f9; color: #475569; font-weight: 600; border-bottom: 2px solid #e2e8f0; }
        td { border-bottom: 1px solid #f1f5f9; color: #334155; }
    </style>
</head>
<body>
    <div class="sidebar">
        <div>
            <div class="sidebar-brand">Gemini Store 🏪</div>
            <ul class="sidebar-menu">
                <li><a href="index.php">📊 Dashboard Utama</a></li>
                <li><a href="tambah.php">➕ Tambah Produk</a></li>
                <li><a href="transaksi.php">🛒 Kasir Transaksi</a></li>
                <li><a href="riwayat.php" class="active">📜 Riwayat Penjualan</a></li>
            </ul>
        </div>
    </div>
    <div class="main-content">
        <div class="data-card">
            <h2>📜 Jurnal & Jurnal Riwayat Penjualan</h2>
            <p>Data rekam transaksi komoditas otomatis secara real-time.</p>
            <table>
                <thead>
                    <tr>
                        <th>Waktu Log</th>
                        <th>ID Transaksi</th>
                        <th>Komoditas</th>
                        <th>Harga Pokok</th>
                        <th>Qty</th>
                        <th>Subtotal Pembayaran</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    if(mysqli_num_rows($result) == 0) {
                        echo "<tr><td colspan='6' style='text-align:center; color:#999;'>Belum ada rekaman log transaksi.</td></tr>";
                    }
                    while($row = mysqli_fetch_assoc($result)) { 
                    ?>
                    <tr>
                        <td><?= $row['tanggal_transaksi']; ?></td>
                        <td><span style="color: var(--primary); font-weight: bold;">#TRX-<?= $row['id_transaksi']; ?></span></td>
                        <td><b><?= $row['nama_produk']; ?></b></td>
                        <td>Rp <?= number_format($row['harga'], 0, ',', '.'); ?></td>
                        <td><?= $row['jumlah_beli']; ?> pcs</td>
                        <td style="color: var(--success); font-weight: 700;">Rp <?= number_format($row['total_harga'], 0, ',', '.'); ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>