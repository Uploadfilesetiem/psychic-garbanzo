-- Database: toko_sembako
CREATE DATABASE IF NOT EXISTS toko_sembako;
USE toko_sembako;

-- Tabel Users (Hanya untuk referensi, tapi login kita tetap tanpa database sesuai permintaan sebelumnya, 
-- atau bisa digunakan jika ingin dikembangkan. Di project ini kita tetap hardcoded agar aman & cepat).
-- Namun untuk pelengkap database UKK, kita sediakan tabel produk dan transaksi.

-- Tabel Produk
CREATE TABLE IF NOT EXISTS produk (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_produk VARCHAR(100) NOT NULL,
    harga INT NOT NULL,
    stok INT NOT NULL
);

-- Tabel Transaksi
CREATE TABLE IF NOT EXISTS transaksi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    produk_id INT NOT NULL,
    jumlah INT NOT NULL,
    total_harga INT NOT NULL,
    tanggal_transaksi TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (produk_id) REFERENCES produk(id) ON DELETE CASCADE
);

-- Insert Data Awal Sembako (Seeders)
INSERT INTO produk (nama_produk, harga, stok) VALUES
('Beras Premium 1kg', 14000, 50),
('Minyak Goreng 1L', 18000, 30),
('Gula Pasir 1kg', 15000, 40),
('Telur Ayam 1kg', 26000, 25),
('Mi Instan Soto', 3500, 100);
