<?php
session_start();
if (isset($_SESSION['login'])) {
    header("Location: index.php");
    exit;
}

$error = false;
if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Login Tanpa Database (Hardcoded untuk keamanan & kecepatan UKK)
    if ($username === 'admin' && $password === 'admin123') {
        $_SESSION['login'] = true;
        $_SESSION['user'] = $username;
        header("Location: index.php");
        exit;
    } else {
        $error = true;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login - Toko Sembako Gemini</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #eef2f3; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .login-box { background: #fff; padding: 40px; border-radius: 10px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); width: 350px; text-align: center; }
        h2 { color: #2c3e50; margin-bottom: 5px; font-size: 24px; }
        p { color: #7f8c8d; margin-bottom: 30px; font-size: 14px; }
        input[type="text"], input[type="password"] { width: 100%; padding: 12px; margin: 8px 0; border: 1px solid #ccc; border-radius: 6px; box-sizing: border-box; font-size: 14px; }
        button { width: 100%; padding: 12px; background: #3498db; border: none; color: white; font-size: 16px; font-weight: bold; border-radius: 6px; cursor: pointer; margin-top: 15px; transition: 0.3s; }
        button:hover { background: #2980b9; }
        .error { color: #e74c3c; font-size: 14px; margin-bottom: 10px; font-weight: bold; }
    </style>
</head>
<body>
<div class="login-box">
    <h2>Toko Sembako Gemini</h2>
    <p>Ujian Praktik Kenaikan Kelas (UKK)</p>
    <?php if ($error) : ?>
        <div class="error">Username / Password Salah!</div>
    <?php endif; ?>
    <form action="" method="POST">
        <input type="text" name="username" placeholder="Username (admin)" required autocomplete="off">
        <input type="password" name="password" placeholder="Password (admin123)" required>
        <button type="submit" name="submit">LOG IN</button>
    </form>
</div>
</body>
</html>