<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

require 'config.php';

// --- LOGIKA CRUD PRODUK ---
// 1. Tambah Produk (Create)
if (isset($_POST['tambah_produk'])) {
    $nama = mysqli_real_escape_string($conn, $_POST['nama_produk']);
    $harga = intval($_POST['harga']);
    $stok = intval($_POST['stok']);
    
    $query = "INSERT INTO produk (nama_produk, harga, stok) VALUES ('$nama', $harga, $stok)";
    mysqli_query($conn, $query);
    header("Location: index.php");
    exit;
}

// 2. Hapus Produk (Delete)
if (isset($_GET['hapus_produk'])) {
    $id = intval($_GET['hapus_produk']);
    $query = "DELETE FROM produk WHERE id = $id";
    mysqli_query($conn, $query);
    header("Location: index.php");
    exit;
}

// 3. Edit Produk (Update Proses)
if (isset($_POST['update_produk'])) {
    $id = intval($_POST['id']);
    $nama = mysqli_real_escape_string($conn, $_POST['nama_produk']);
    $harga = intval($_POST['harga']);
    $stok = intval($_POST['stok']);
    
    $query = "UPDATE produk SET nama_produk='$nama', harga=$harga, stok=$stok WHERE id=$id";
    mysqli_query($conn, $query);
    header("Location: index.php");
    exit;
}

// --- LOGIKA TRANSAKSI ---
$sukses_transaksi = false;
$nota_transaksi = [];

if (isset($_POST['bayar_transaksi'])) {
    $produk_id = intval($_POST['produk_id']);
    $jumlah = intval($_POST['jumlah']);
    
    // Ambil data produk untuk cek harga dan stok
    $res_p = mysqli_query($conn, "SELECT * FROM produk WHERE id = $produk_id");
    if (mysqli_num_rows($res_p) > 0) {
        $p_data = mysqli_fetch_assoc($res_p);
        
        if ($p_data['stok'] >= $jumlah) {
            // Hitung Otomatis (Poin Krusial Brosur): Jumlah Beli x Harga
            $total_harga = $jumlah * $p_data['harga'];
            
            // Simpan ke tabel transaksi
            $q_trans = "INSERT INTO transaksi (produk_id, jumlah, total_harga) VALUES ($produk_id, $jumlah, $total_harga)";
            if (mysqli_query($conn, $q_trans)) {
                // Kurangi stok produk
                $stok_baru = $p_data['stok'] - $jumlah;
                mysqli_query($conn, "UPDATE produk SET stok = $stok_baru WHERE id = $produk_id");
                
                $sukses_transaksi = true;
                $nota_transaksi = [
                    'nama' => $p_data['nama_produk'],
                    'jumlah' => $jumlah,
                    'total' => $total_harga
                ];
            }
        } else {
            echo "<script>alert('Stok tidak mencukupi!'); window.location='index.php';</script>";
            exit;
        }
    }
}

// Ambil semua data produk (Read)
$produk_list = mysqli_query($conn, "SELECT * FROM produk ORDER BY id DESC");

// Ambil semua data riwayat transaksi beserta nama produk (Join)
$transaksi_list = mysqli_query($conn, "SELECT t.*, p.nama_produk FROM transaksi t JOIN produk p ON t.produk_id = p.id ORDER BY t.id DESC");

// Mode Edit Data Trigger
$edit_mode = false;
$prod_edit = [];
if (isset($_GET['edit_produk'])) {
    $edit_mode = true;
    $id_edit = intval($_GET['edit_produk']);
    $res_edit = mysqli_query($conn, "SELECT * FROM produk WHERE id = $id_edit");
    $prod_edit = mysqli_fetch_assoc($res_edit);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Toko Sembako Gemini</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f8f9fa; margin: 0; padding: 20px; color: #333; }
        .header { background: #2c3e50; color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
        .header h1 { margin: 0; font-size: 22px; }
        .logout-btn { background: #e74c3c; color: white; padding: 8px 15px; text-decoration: none; border-radius: 4px; font-weight: bold; }
        .container { display: flex; gap: 20px; flex-wrap: wrap; }
        .card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); flex: 1; min-width: 300px; }
        .card h2 { margin-top: 0; color: #2980b9; border-bottom: 2px solid #eee; padding-bottom: 10px; font-size: 18px; }
        
        /* Form & Table Styling */
        label { display: block; margin: 10px 0 5px; font-weight: bold; }
        input[type="text"], input[type="number"], select { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        button.btn { background: #27ae60; color: white; border: none; padding: 10px 15px; font-weight: bold; border-radius: 4px; cursor: pointer; width: 100%; margin-top: 15px; }
        button.btn:hover { background: #219a52; }
        button.btn-edit { background: #f39c12; }
        button.btn-edit:hover { background: #d35400; }
        
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        table, th, td { border: 1px solid #ddd; }
        th, td { padding: 10px; text-align: left; }
        th { background-color: #f2f2f2; }
        .action-link { text-decoration: none; padding: 3px 8px; border-radius: 3px; font-size: 12px; font-weight: bold; }
        .edit-link { background: #f1c40f; color: black; }
        .delete-link { background: #e74c3c; color: white; }
        
        .nota { background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; border-radius: 5px; margin-bottom: 15px; }
    </style>
</head>
<body>

<div class="header">
    <div>
        <h1>Sistem Toko Sembako Gemini</h1>
        <small>SMK Muhammadiyah Bambanglipuro | RPL X | Selamat Datang, <?= $_SESSION['user']; ?></small>
    </div>
    <a href="logout.php" class="logout-btn">LOGOUT</a>
</div>

<?php if ($sukses_transaksi): ?>
    <div class="nota">
        <h3>🎉 Transaksi Berhasil! (Hitung Otomatis Sukses)</h3>
        <p>Produk: <strong><?= $nota_transaksi['name']; ?></strong></p>
        <p>Jumlah: <strong><?= $nota_transaksi['jumlah']; ?>x</strong></p>
        <p>Total Bayar: <strong>Rp <?= number_format($nota_transaksi['total'], 0, ',', '.'); ?></strong></p>
    </div>
<?php endif; ?>

<div class="container">
    
    <!-- 1. FORM CRUD PRODUK (CREATE / UPDATE) -->
    <div class="card">
        <?php if ($edit_mode): ?>
            <h2>Update Data Produk</h2>
            <form action="" method="POST">
                <input type="hidden" name="id" value="<?= $prod_edit['id']; ?>">
                <label>Nama Produk</label>
                <input type="text" name="nama_produk" value="<?= $prod_edit['nama_produk']; ?>" required>
                <label>Harga (Rp)</label>
                <input type="number" name="harga" value="<?= $prod_edit['harga']; ?>" required>
                <label>Stok</label>
                <input type="number" name="stok" value="<?= $prod_edit['stok']; ?>" required>
                <button type="submit" name="update_produk" class="btn btn-edit">SIMPAN PERUBAHAN</button>
                <a href="index.php" style="display:block; text-align:center; margin-top:10px; color:#7f8c8d;">Batal</a>
            </form>
        <?php else: ?>
            <h2>Tambah Produk Baru (Create)</h2>
            <form action="" method="POST">
                <label>Nama Produk</label>
                <input type="text" name="nama_produk" placeholder="Contoh: Beras Premium 5kg" required>
                <label>Harga (Rp)</label>
                <input type="number" name="harga" placeholder="Contoh: 70000" required>
                <label>Stok</label>
                <input type="number" name="stok" placeholder="Contoh: 20" required>
                <button type="submit" name="tambah_produk" class="btn">TAMBAH PRODUK</button>
            </form>
        <?php endif; ?>
    </div>

    <!-- 2. LOGIKA TRANSAKSI (POIN KRUSIAL BROSUR) -->
    <div class="card">
        <h2>Transaksi Baru / Kasir</h2>
        <form action="" method="POST">
            <label>Pilih Produk Sembako</label>
            <select name="produk_id" required>
                <option value="">-- Pilih Sembako Tersedia --</option>
                <?php 
                // Reset pointer data produk untuk dropdown
                mysqli_data_seek($produk_list, 0);
                while($p = mysqli_fetch_assoc($produk_list)): 
                ?>
                    <option value="<?= $p['id']; ?>"><?= $p['nama_produk']; ?> (Rp <?= number_format($p['harga'], 0, ',', '.'); ?>) [Stok: <?= $p['stok']; ?>]</option>
                <?php endwhile; ?>
            </select>
            
            <label>Jumlah Beli</label>
            <input type="number" name="jumlah" value="1" min="1" required>
            
            <button type="submit" name="bayar_transaksi" class="btn" style="background:#2980b9;">PROSES & HITUNG OTOMATIS</button>
        </form>
    </div>

</div>

<br>

<div class="card">
    <h2>Data Stok Sembako (Read & Delete)</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama Sembako</th>
                <th>Harga Satuan</th>
                <th>Stok Sedia</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            mysqli_data_seek($produk_list, 0);
            if (mysqli_num_rows($produk_list) == 0): 
            ?>
                <tr><td colspan="5" style="text-align:center;">Data produk kosong.</td></tr>
            <?php 
            else:
                while($p = mysqli_fetch_assoc($produk_list)): 
            ?>
                <tr>
                    <td><?= $p['id']; ?></td>
                    <td><?= $p['nama_produk']; ?></td>
                    <td>Rp <?= number_format($p['harga'], 0, ',', '.'); ?></td>
                    <td><?= $p['stok']; ?></td>
                    <td>
                        <a href="index.php?edit_produk=<?= $p['id']; ?>" class="action-link edit-link">Edit</a>
                        <a href="index.php?hapus_produk=<?= $p['id']; ?>" class="action-link delete-link" onclick="return confirm('Hapus produk ini?')">Hapus</a>
                    </td>
                </tr>
            <?php 
                endwhile;
            endif; 
            ?>
        </tbody>
    </table>
</div>

<br>

<div class="card">
    <h2>Riwayat Transaksi Toko Gemini</h2>
    <table>
        <thead>
            <tr>
                <th>ID Transaksi</th>
                <th>Nama Produk</th>
                <th>Jumlah Beli</th>
                <th>Total Bayar</th>
                <th>Waktu Transaksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if (mysqli_num_rows($transaksi_list) == 0): ?>
                <tr><td colspan="5" style="text-align:center;">Belum ada transaksi dilakukan.</td></tr>
            <?php else: ?>
                <?php while($t = mysqli_fetch_assoc($transaksi_list)): ?>
                    <tr>
                        <td>#TRX-<?= $t['id']; ?></td>
                        <td><?= $t['nama_produk']; ?></td>
                        <td><?= $t['jumlah']; ?>x</td>
                        <td><strong>Rp <?= number_format($t['total_harga'], 0, ',', '.'); ?></strong></td>
                        <td><?= $t['tanggal_transaksi']; ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</body>
</html>